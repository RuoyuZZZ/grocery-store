require 'test_helper'

class BreedTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
