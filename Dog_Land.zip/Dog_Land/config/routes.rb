Rails.application.routes.draw do
  get '/view' => 'order#view'
  get '/item' => 'order_item#index'
  post '/edit_quantity' => 'order_item#edit_quantity'
  post '/add' => 'order_item#create'
  post '/remove' => 'order_item#remove'
  get '/login' => 'user#login'
  get '/register' => 'user#register'
  get '/delete' => 'sessions#delete'
  post '/create' => 'user#create'
  post '/sessions' => 'sessions#create'
  devise_for :admin_users, ActiveAdmin::Devise.config
  ActiveAdmin.routes(self)
  resources :product, only: [:index, :show] do
    collection do
      get 'results'
    end
  end

  resources :breed, only: [:index]
  resources :search, only: [:index]
  resources :order, only: [:index]

  root to: 'product#index'
end
