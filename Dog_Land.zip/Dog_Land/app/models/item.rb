class Item < ApplicationRecord
  belongs_to :product
  belongs_to :order

  validates :product, :order, :unit_price, :quantity, presence: true
end
