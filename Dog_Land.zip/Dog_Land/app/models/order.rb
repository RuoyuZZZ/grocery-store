class Order < ApplicationRecord
  belongs_to :user
  has_many :items
  has_many :products, through: :items
  accepts_nested_attributes_for :items, allow_destroy: true

  validates :subtotal, :total, :status, :user, :product, presence: true
end
