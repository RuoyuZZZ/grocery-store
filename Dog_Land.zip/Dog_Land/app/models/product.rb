class Product < ApplicationRecord
  has_many :items
  has_many :orders, through: :items

  validates :name, :breed, :age, :gender, :price, :picture, presence: true
  mount_uploader :picture, AvatarUploader
end
