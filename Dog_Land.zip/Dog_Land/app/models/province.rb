class Province < ApplicationRecord
  validates :name, :rate, presence: true
end
