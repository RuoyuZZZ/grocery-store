class User < ApplicationRecord
  validates :username, :password, :shippingAddress, :presence => true
  validates :username, :uniqueness => true
end
