class SearchController < ApplicationController
  def index
    @breed = Breed.all
    product = Product.where('name LIKE ?', "%#{params[:q]}%")

    if params[:breed_name].empty?
      @product = product.page params[:page]
    else
      breed = Breed.where(:name => params[:breed_name]).first
      @product = product.where(:breed => breed.name).page params[:page]
    end
  end
end
