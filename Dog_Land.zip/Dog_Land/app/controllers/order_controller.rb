class OrderController < ApplicationController
  def index

  end

  def view
    @product = Product.find(session[:product_cart][:id])
  end
end
