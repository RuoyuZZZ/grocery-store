class ApplicationController < ActionController::Base
  # before_action :initialize_quantity
  #
  # private
  # def initialize_quantity
  #   if session[:quantity].nil?
  #     @quantity = 1
  #   else
  #     @quantity = session[:quantity]
  #   end
  # end
end
