class ProductController < ApplicationController
  def index
    @product = Product.all.page params[:page]
    @breed = Breed.all
    if session[:id]
      @user = User.find(session[:id])
    end
  end

  def show
    @product = Product.find(params[:id])
  end

  def results
    @breed = Breed.all
    @product = Product.where(:status => params[:product_status]).page params[:page]
  end
end
