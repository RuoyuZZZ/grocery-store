class BreedController < ApplicationController
  def index
    @breed = Breed.all
    @product = Product.where(:breed => params[:breed_name]).page params[:page]
  end
end
