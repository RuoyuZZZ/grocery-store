class SessionsController < ApplicationController
  def create
    user = User.find_by(:username => params[:username])

    # if user && user.authenticate(params[:password])
    if user && user.password == params[:password]
      session[:id] = user.id
      redirect_to root_path
    else
      flash[:login_errors] = 'Invalid credentials'
      redirect_to '/login'
    end
  end

  def delete
    session.clear
    redirect_to root_path
  end
end
