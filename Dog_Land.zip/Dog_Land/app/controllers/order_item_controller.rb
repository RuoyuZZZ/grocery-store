class OrderItemController < ApplicationController
  skip_before_action :verify_authenticity_token
  before_action :initialize_session

  def index
    @item = session[:product_cart]
  end

  def create
    id = params[:id].to_i
    quantity = params[:quantity].to_i
    session[:product_cart] << {:id => id, :quantity => quantity}

    redirect_to '/item'
  end

  def edit_quantity
    id = params[:id].to_i
    quantity = params[:quantity].to_i
    #session[:product_cart].each { |item| item[:quantity] = quantity if item[:id] == id }
    session[:product_cart].delete_if { |h| h["id"] == id }
    session[:product_cart] << {:id => id, :quantity => quantity}
  #  session[:product_cart] = []
    redirect_to '/item'
  end

  def remove
    id = params[:id].to_i
    session[:product_cart].delete_if { |h| h["id"] == id }
    redirect_to '/item'
  end

  private
  def initialize_session
    session[:product_cart] ||= []
  end
end
