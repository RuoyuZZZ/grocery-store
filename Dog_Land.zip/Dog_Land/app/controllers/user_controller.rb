class UserController < ApplicationController
  def login
  end

  def register
  end

  def create
    user = User.new(:username => params[:username],
                     :password => params[:password],
                     :shippingAddress => params[:shipping_address])

    if user.save
      redirect_to root_path
    else
      flash[:register_errors] = user.errors.full_messages
      redirect_to '/register'
    end
  end

  private
    def user_params
      params.require(:users).permit(:username, :password, :password_confirm, :shipping_address)
    end
end
