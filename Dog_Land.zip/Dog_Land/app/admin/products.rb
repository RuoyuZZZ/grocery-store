ActiveAdmin.register Product do
permit_params :name, :breed, :age, :gender, :price, :picture, :status
end
