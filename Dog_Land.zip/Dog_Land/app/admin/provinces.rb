ActiveAdmin.register Province do
permit_params :name, :rate
end
