ActiveAdmin.register Order do
  permit_params :subtotal, :total, :status, :user, items: [:id, :product_id, :order_id, :_destroy]

  form do |f|
    f.semantic_errors *f.object.errors.keys

    f.inputs "Order" do
      f.input :subtotal
      f.input :total
      f.input :status
      f.input :user
      f.has_many :items, allow_destroy: true do |n_f|
        n_f.input :product
      end
    end

    f.actions
  end
end
