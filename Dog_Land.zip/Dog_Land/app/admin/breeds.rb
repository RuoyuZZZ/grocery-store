ActiveAdmin.register Breed do
permit_params :name
end
