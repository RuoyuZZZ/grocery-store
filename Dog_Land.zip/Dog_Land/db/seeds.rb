# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

require 'net/http'
require 'json'
require 'pp'

url = 'https://dog.ceo/api/breeds/list/all'
uri = URI(url)
response = Net::HTTP.get(uri)

json = JSON.parse(response)
breeds = json['message']

breeds.each do |breed|
  url = 'https://dog.ceo/api/breed/'+ breed[0] +'/images/random'
  uri = URI(url)
  response = Net::HTTP.get(uri)
  json = JSON.parse(response)
  picture = json['message']

  dog = Product.new(:name => Faker::Dog.name,
                    :breed => breed[0],
                    :age => Faker::Number.between(1, 5),
                    :gender => Faker::Dog.gender,
                    :price => Faker::Number.decimal(2),
                    :picture => picture,
                    :status => 'On Sale')

  dog.save

  category = Breed.new(:name => breed[0])
  category.save
end

# dog = Product.first
puts "There are #{Product.count} breeds."
# AdminUser.create!(email: 'admin@example.com', password: 'password', password_confirmation: 'password') if Rails.env.development?
